package com.oraclejava.springcore3;

import java.util.List;
import java.util.Map;

import org.springframework.context.support.AbstractApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.jdbc.core.JdbcTemplate;

public class EmpMain {

	public static void main(String[] args) {
		AbstractApplicationContext ctx = 
				new ClassPathXmlApplicationContext("SpringConfig.xml");
		
		JdbcTemplate jdbcTemplate = 
				ctx.getBean(JdbcTemplate.class);
		
		// select * from employees
		List<Map<String, Object>> list =
				jdbcTemplate.queryForList("select * from employees");
		
		for (Map<String, Object> map : list) {
			System.out.println(map.get("first_name"));
		}
		
		ctx.close();

	}

}
