package com.oraclejava;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Demojpa2Application {

	public static void main(String[] args) {
		SpringApplication.run(Demojpa2Application.class, args);
	}

}
