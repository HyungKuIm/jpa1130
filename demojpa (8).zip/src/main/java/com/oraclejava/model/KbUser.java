package com.oraclejava.model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@Entity
public class KbUser {
	@Id
	@GeneratedValue(generator = "kbuser_generator", 
		strategy = GenerationType.SEQUENCE)
	@SequenceGenerator(name = "kbuser_generator", 
		allocationSize = 1, sequenceName = "kbuser_seq")
	private Long id;   // 사용자id
	private String username;  //사용자이름
	private String password;  //패스워드
}






