package com.oraclejava.util;

public enum Authority {

}
