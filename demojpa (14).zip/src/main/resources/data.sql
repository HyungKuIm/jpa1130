insert into book(id, title, contents) values (book_seq.nextval, '달러구트 꿈 백화점', '잠들어야만 입장 가능한 꿈 백화점에서 일어나는 비밀스럽고도 기묘하며 가슴 뭉클한 판타지 소설');
insert into book(id, title, contents) values (book_seq.nextval, '주린이가 가장 알고 싶은 최다질문 TOP 77', '‘염블리’ 염승환이 전하는 주식투자 시 필수지식과 태도,경험을 담은 주식투자 바이블!');
insert into book(id, title, contents) values (book_seq.nextval, '미드나잇 라이브러리', '밤 12시, 죽기 바로 전에만 열리는 마법의 도서관에서 인생의 두 번째 기회를 드립니다');
insert into book(id, title, contents) values (book_seq.nextval, '조국의 시간', '조국의 생생한 육성으로 듣는다. 그의 아픔과 진실, 말하지 못한 생각');
insert into book(id, title, contents) values (book_seq.nextval, '소크라테스 익스프레스', '인생에서 길을 잃는 수많은 순간마다 이 철학자들의 목소리가 들려올 것이다”');
