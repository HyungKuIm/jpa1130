package com.oraclejava.config;

import org.springframework.boot.ApplicationArguments;
import org.springframework.boot.ApplicationRunner;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Component;

import com.oraclejava.dao.KbUserRepository;
import com.oraclejava.model.KbUser;
import com.oraclejava.util.Authority;

@Component
public class UserCreator implements ApplicationRunner{

	private final PasswordEncoder passwordEncoder;
	private final KbUserRepository kbUserRepository;
	
	//의존성 주입(DI)
	public UserCreator(PasswordEncoder passwordEncoder, KbUserRepository kbUserRepository) {
		super();
		this.passwordEncoder = passwordEncoder;
		this.kbUserRepository = kbUserRepository;
	}
	
	@Override
	public void run(ApplicationArguments args) throws Exception {
		KbUser user = new KbUser();
		user.setUsername("son");
		user.setPassword(passwordEncoder.encode("qatar"));
		user.setEmail("sony@totunham.co.uk");
		user.setAdmin(true);
		user.setAuthority(Authority.ADMIN);
		
		kbUserRepository.save(user);
		
	}

	

}
