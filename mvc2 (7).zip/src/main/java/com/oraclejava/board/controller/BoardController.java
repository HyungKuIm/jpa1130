package com.oraclejava.board.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

import com.oraclejava.board.domain.Article;
import com.oraclejava.board.domain.Comment;
import com.oraclejava.board.service.ArticleService;
import com.oraclejava.board.service.CommentService;

@Controller
@RequestMapping("/board")  
public class BoardController {
	
	@Autowired
	private ArticleService articleService;
	@Autowired
	private CommentService commentService;
	
	@RequestMapping
	public String index(Model model) {
		
		// 서비스에서 글목록 취득
		List<Article> articleList = articleService.findAll();
		
		// 각 개시글에 대해 댓글(있으면) 추가
		for (Article article : articleList) {
			List<Comment> commentList = 
					commentService.findByArticleId(article.getId());
			article.setCommentList(commentList);
		}
		
		// 글목록을 모델에 저장
		model.addAttribute("articleList", articleList);
		
		return "boardView";
	}

}





