package com.oraclejava.controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

import com.oraclejava.domain.Phone;

@Controller
@RequestMapping("/phone")
public class PhoneController {
	
	@RequestMapping
	public String index(Model model) {
		Phone phone = new Phone("아이폰 14", 15.4, "5G", 1243000);
		model.addAttribute("phone", phone);
		return "phoneView";
	}
	
}
