package com.oraclejava.board.service;

import java.util.List;

import com.oraclejava.board.domain.Comment;

public interface CommentService {
	public List<Comment> findByArticleId(int articleId);
}
