package com.oraclejava.board.form;

// 글 입력을 위한 폼
public class ArticleForm {
	
	private String name;  // 글쓴이  
	private String content;  // 글내용
	
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getContent() {
		return content;
	}
	public void setContent(String content) {
		this.content = content;
	}
	
	//get, set
	
}
