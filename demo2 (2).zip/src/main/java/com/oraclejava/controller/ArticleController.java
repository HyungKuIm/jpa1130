package com.oraclejava.controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.oraclejava.domain.Article;
import com.oraclejava.form.ArticleForm;
import com.oraclejava.repository.ArticleRepository;

@RequestMapping("/board")
@Controller
public class ArticleController {

	private ArticleRepository articleRepository;

	public ArticleController(ArticleRepository articleRepository) {
		super();
		this.articleRepository = articleRepository;
	}
	
	// 게시글 폼 초기화
	@ModelAttribute
	public ArticleForm setArticleForm() {
		return new ArticleForm();
	}
	
	// 게시글 쓰기
	@RequestMapping(value="/write", method=RequestMethod.GET)
	public String write(Model model) {
		return "write";
	}
	
	@RequestMapping
	public String findAll(Model model) {
		List<Article> arti = new ArrayList<>();
		
		articleRepository.findAll().forEach(e -> arti.add(e));
		
		model.addAttribute("arti", arti);
		return "board";
	}
}
