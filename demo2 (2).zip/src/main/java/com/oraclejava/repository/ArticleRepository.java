package com.oraclejava.repository;

import com.oraclejava.domain.Article;

public interface ArticleRepository {
	Iterable<Article> findAll();
	Article save(Article article);  // --> 글쓰기
}
