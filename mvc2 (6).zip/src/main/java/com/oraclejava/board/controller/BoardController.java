package com.oraclejava.board.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

import com.oraclejava.board.domain.Article;
import com.oraclejava.board.service.ArticleService;

@Controller
@RequestMapping("/board")  
public class BoardController {
	
	@Autowired
	private ArticleService articleService;
	
	@RequestMapping
	public String index(Model model) {
		
		// 서비스에서 글목록 취득
		List<Article> articleList = articleService.findAll();
		// 글목록을 모델에 저장
		model.addAttribute("articleList", articleList);
		
		return "boardView";
	}

}





