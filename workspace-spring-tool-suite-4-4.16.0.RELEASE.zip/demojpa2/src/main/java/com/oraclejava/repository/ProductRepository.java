package com.oraclejava.repository;

import org.springframework.data.repository.CrudRepository;

import com.oraclejava.model.Product;

public interface ProductRepository 
	extends CrudRepository<Product, String>{

}
