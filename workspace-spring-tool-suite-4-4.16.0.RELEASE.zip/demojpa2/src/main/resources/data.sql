insert into product(id,name,type,brand,description)
values('MOB01','S22','Mobile','Samsung', 'Very nice phone');
insert into product(id,name,type,brand,description)
values('MOB02','S22+','Mobile','Samsung', 'Very nice and big phone');
insert into product(id,name,type,brand,description)
values('TLV01','중소기업TV','Television','주연테크', 'TV 잘만 나옴');
insert into product(id,name,type,brand,description)
values('CAM01','줌 강의용 웹캠','DSLR Camera','Canon', '화질 진짜 좋음');
insert into product(id,name,type,brand,description)
values('SPK01','PC용 스피커','Home Theater Speaker','JBL', '소리 빵빵하게 잘 나오네');