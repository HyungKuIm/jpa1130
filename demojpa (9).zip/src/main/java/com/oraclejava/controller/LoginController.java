package com.oraclejava.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;

import com.oraclejava.model.KbUser;

@Controller
public class LoginController {

	// 로그인
	@GetMapping("/login")
	public String login() {
		return "login";
	}
	
	// 회원가입
	@GetMapping("/register")
	public String register(@ModelAttribute("user") KbUser kbUser) {  // 이때 오브젝트의 이름은 "bkUser"
		return "register";
	}
}





