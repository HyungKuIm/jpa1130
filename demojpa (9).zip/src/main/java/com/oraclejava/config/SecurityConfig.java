package com.oraclejava.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.core.authority.AuthorityUtils;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.web.SecurityFilterChain;
import org.springframework.security.web.util.matcher.AntPathRequestMatcher;

import com.oraclejava.dao.KbUserRepository;
import com.oraclejava.model.KbUser;

@Configuration
public class SecurityConfig {
	
	private final KbUserRepository kbUserRepository;
	
	// 의존성 주입(DI)
	public SecurityConfig(KbUserRepository kbUserRepository) {
		super();
		this.kbUserRepository = kbUserRepository;
	}

	@Bean
	public PasswordEncoder passwordEncoder() {
		//패스워드 암호화 사용(BCrypt) --> Google, MS, Apple, Meta에서 사용중
		return new BCryptPasswordEncoder();
	}
	
	

	@Bean
	public SecurityFilterChain filterChain(HttpSecurity http)
		throws Exception {
		// 인증할 요청을 설정
		http.authorizeHttpRequests(auth -> 
			
			auth
			// css, images 폴더처럼 정적 리소스 엑세스 가능하도록 함
			.mvcMatchers("/css/**", "/js/**", "/images/**", "/webjars/**",
							"/favicon.*", "/icon-*").permitAll()
			// 여기에 풀어주고 싶은 url을 지정하면 됨
			.mvcMatchers("/register", "/login").permitAll()
			// 화이트리스트 방식(모든 요청을 막음)
			.anyRequest().authenticated())
			.formLogin(login -> login
					.loginPage("/login")
					.defaultSuccessUrl("/")
					.permitAll())
			//로그아웃 설정 추가
			.logout(logout -> logout
					.logoutRequestMatcher(new AntPathRequestMatcher("/logout"))
					.permitAll());
		return http.build();
		
	}
	
	@Bean
	public UserDetailsService userDetailsService() {
		//사용자 작성
		return username -> {
			KbUser user = kbUserRepository.findByUsername(username)
							.orElseThrow(() -> 
								new UsernameNotFoundException(
										username + "이라는 사용자아이디는 없는데요ㅠㅠ"));
			return new User(user.getUsername(), user.getPassword(),
					AuthorityUtils.createAuthorityList("ADMIN"));
		};
		
		
	}
}







