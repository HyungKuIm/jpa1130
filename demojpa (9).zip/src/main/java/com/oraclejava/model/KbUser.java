package com.oraclejava.model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;

import com.oraclejava.util.Authority;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@Entity
public class KbUser {
	@Id
	@GeneratedValue(generator = "kbuser_generator", 
		strategy = GenerationType.SEQUENCE)
	@SequenceGenerator(name = "kbuser_generator", 
		allocationSize = 1, sequenceName = "kbuser_seq")
	private Long id;   // 사용자id
	private String username;  //사용자이름
	private String password;  //패스워드
	
	private String email; // 사용자 이메일
	
	private int gender;  //성별(기본값 0)
	private boolean admin; // 관리자인지 아닌지(기본값 false, 관리자 true)
	private Authority authority;  // 회원 등급
}






